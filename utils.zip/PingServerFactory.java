import java.net.InetSocketAddress;
import rmi.*;

public class PingServerFactory implements ServerFactory {
    
    public static void main(String args[]) throws RMIException {
        InetSocketAddress address = new InetSocketAddress("server", 9999);
        PingServerFactory factory = new PingServerFactory();
        Skeleton<ServerFactory> skeleton = new Skeleton(ServerFactory.class, factory, address);
        skeleton.start();
    }
    public PingServer makePingServer() throws RMIException {
        PingPongServer server = new PingPongServer();
        InetSocketAddress address = new InetSocketAddress(49999);
        Skeleton<PingServer> skeleton = new Skeleton(PingServer.class, server, address);
        skeleton.start();
        PingServer ping_server = Stub.create(PingServer.class, skeleton, "server");
        return ping_server;
    };
}
