import rmi.*;

public class PingPongServer implements PingServer {
    public String ping(int idNumber) throws RMIException {
        return "Pong " + idNumber;
    }
}
