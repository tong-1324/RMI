docker build -t 291rmi/base .
docker build -t 291rmi/server -f DockerServer .
docker build -t 291rmi/client -f DockerClient .
docker run -d --name server --hostname="server" 291rmi/server /bin/bash -c "cd /RMI; javac ServerFactory.java; javac PingServer.java; javac PingPongServer.java; javac PingServerFactory.java; java PingServerFactory;"
sleep 10s
docker run -d --name client --link server 291rmi/client /bin/bash -c "cd /RMI; javac PingServer.java; javac ServerFactory.java; javac PingPongClient.java; java PingPongClient"
docker logs -f client