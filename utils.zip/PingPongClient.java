import java.net.InetSocketAddress;
import rmi.*;

public class PingPongClient {
    public static void main(String args[]) throws RMIException {
        InetSocketAddress address = new InetSocketAddress("server", 9999);
        ServerFactory server_factory = Stub.create(ServerFactory.class, address);
        PingServer ping_server = server_factory.makePingServer();
        for(int i = 0; i < 10; i++) {
            System.out.println(ping_server.ping(i));
        }
    }
}
