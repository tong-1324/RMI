import rmi.*;

public interface ServerFactory {
    public PingServer makePingServer() throws RMIException;
}
