import rmi.*;

public interface PingServer {
    public String ping(int idNumber) throws RMIException;
}
